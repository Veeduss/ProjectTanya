﻿namespace Tanya.Game.Apex.Feature.Aim.Enums
{
    public enum TargetType
    {
        None,
        Enemy,
        All
    }
}